

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="page-title">
                <i class="bi bi-collection"></i> Product Collection
            </h1>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary-custom btn-custom">
                <i class="bi bi-plus-lg"></i> Add New Product
            </a>
        </div>
    </div>

    <?php if(count($products) > 0): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th><i class="bi bi-tag"></i> ID</th>
                        <th><i class="bi bi-box"></i> Product Name</th>
                        <th><i class="bi bi-file-text"></i> Description</th>
                        <th><i class="bi bi-currency-dollar"></i> Price</th>
                        <th><i class="bi bi-stack"></i> Quantity</th>
                        <th><i class="bi bi-tools"></i> Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span class="badge" style="background: var(--primary-color);"><?php echo e($product->id); ?></span>
                            </td>
                            <td>
                                <strong><?php echo e($product->name); ?></strong>
                            </td>
                            <td>
                                <small class="text-muted">
                                    <?php echo e(Str::limit($product->description ?? 'N/A', 50)); ?>

                                </small>
                            </td>
                            <td>
                                <span class="price-badge">$<?php echo e(number_format($product->price, 2)); ?></span>
                            </td>
                            <td>
                                <?php if($product->quantity > 0): ?>
                                    <span class="badge" style="background: var(--success-color);">
                                        <i class="bi bi-check-lg"></i> <?php echo e($product->quantity); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="badge" style="background: var(--danger-color);">
                                        <i class="bi bi-x-lg"></i> Out of Stock
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-sm btn-primary-custom btn-custom" title="View">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-sm btn-warning-custom btn-custom" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger-custom btn-custom" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="no-products">
            <i class="bi bi-inbox"></i>
            <h3>No Products Found</h3>
            <p class="text-muted">Start by adding your first product to get started!</p>
            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary-custom btn-custom mt-3">
                <i class="bi bi-plus-lg"></i> Create First Product
            </a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\narak.documents\NaraKOuk A6 and E6(RUPP Year3 2025-2026)\E6 semester 2\Back end Lesson\Laravel ass\resources\views/products/index.blade.php ENDPATH**/ ?>